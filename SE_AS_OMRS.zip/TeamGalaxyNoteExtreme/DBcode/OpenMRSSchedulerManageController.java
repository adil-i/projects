/**
 * The contents of this file are subject to the OpenMRS Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://license.openmrs.org
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Copyright (C) OpenMRS, LLC.  All Rights Reserved.
 */
package org.openmrs.module.scheduler.web.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openmrs.api.context.Context;
import org.openmrs.api.db.UserDAO;
import org.openmrs.util.PrivilegeConstants;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping; import org.springframework.web.bind.annotation.RequestMethod;
import org.openmrs.User;
import org.openmrs.Role;

import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * The main controller.
 */
@Controller
public class OpenMRSSchedulerManageController {
	
	protected final Log log = LogFactory.getLog(getClass());

	private List<User> getDoctors() {
		Context.addProxyPrivilege("Get Users");
		List<User> users = Context.getUserService().getUsersByRole(new Role("Clinician"));
		return users;
	}

	public Object currentDr = "";
	
	@RequestMapping(value = "/module/scheduler/manage", method = RequestMethod.GET)
	public void manage(ModelMap model) {
		User remoteUser = Context.getAuthenticatedUser();
		System.out.println(remoteUser);
		boolean loggedIn = remoteUser != null;

		model.addAttribute("loggedIn", loggedIn);
		model.addAttribute("user", remoteUser);
		model.addAttribute("doctors", getDoctors());
	}

	@RequestMapping(value = "/module/scheduler/post_appointment", method = RequestMethod.PUT)
	public ResponseEntity postAppointment(@RequestBody ModelMap model) {
		System.out.println(model);
		Connection connect = null;
    		PreparedStatement preparedStatement = null;
		ResultSet rs;
		try{
		    Object data = model.get("data");
        	    connect = getConnection();
        	    String email = "";
        	    //if(userProvidedEmail != "") {
            	//	email = userProvidedEmail;
        	  //  }
        	    User remoteUser = Context.getAuthenticatedUser();
		    String query = "INSERT INTO appointment VALUES (" + remoteUser.toString() 
          		+ ", " + currentDr + ", " + data.toString()
            		+ ", " + data.toString() + ", " + email + ", SYSDATE();\n";
        	    preparedStatement = connect.prepareStatement(query);
        	    rs = preparedStatement.executeQuery();
        	    rs.close();
        	    preparedStatement.close();
    		} catch (Exception e) {
	    	    try {
			throw e;
		    } catch (Exception e1) {
			e1.printStackTrace();
		    }
		} finally {
		    if (preparedStatement != null) {
		    	try {
			    preparedStatement.close();
			} catch (SQLException e) {
			    e.printStackTrace();
			}
		}
		if (connect != null) {
		    try {
			connect.close();
		    } catch (SQLException e) {
			e.printStackTrace();
		    }
		}
	}
	return new ResponseEntity(HttpStatus.OK);
}

	@RequestMapping(value = "/module/scheduler/post_preferences", method = RequestMethod.PUT)
	public ResponseEntity postPreferences(@RequestBody ModelMap model) {
		System.out.println(model);
		return new ResponseEntity(HttpStatus.OK);
	}

	@RequestMapping(value = "/module/scheduler/get_doctor_events", method = RequestMethod.GET)
	public ResponseEntity getDoctorEvents(@RequestBody ModelMap model) {
		System.out.println(model);
		Connection connect = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs;
		try {
		    currentDr = model.get("data");
		    //currentDr = mMap.get("data");
		    connect = getConnection();
		    String query = "select start_time from appointment where (dr_id='" + currentDr + "' and start_time > sysdate());";
		    preparedStatement = connect.prepareStatement(query);
		    rs = preparedStatement.executeQuery();
		    rs.close();
		    preparedStatement.close();
		} catch (Exception e) {
	    	    try {
			throw e;
		} catch (Exception e1) {
		    e1.printStackTrace();
		}
	} finally {
		if (preparedStatement != null) {
		    try {
			preparedStatement.close();
		    } catch (SQLException e) {
			e.printStackTrace();
		    }
		}	      
		if (connect != null) {
		    try {
			connect.close();
		    } catch (SQLException e) {
			e.printStackTrace();
		    }
		}
	    }
	    return new ResponseEntity(HttpStatus.OK);
	}
	
	public Connection getConnection() {
	Connection connect = null;
	try{
		Class.forName("com.mysql.jdbc.Driver");
		connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/openmrs?user=admin&password=Admin123&useSSL=false");
	} catch (Exception e) {
	    try {
			throw e;
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	    }
	return connect;    
	}
}
