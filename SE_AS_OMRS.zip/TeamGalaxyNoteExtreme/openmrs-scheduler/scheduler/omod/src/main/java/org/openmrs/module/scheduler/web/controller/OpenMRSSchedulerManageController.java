/**
 * The contents of this file are subject to the OpenMRS Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://license.openmrs.org
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Copyright (C) OpenMRS, LLC.  All Rights Reserved.
 */
package org.openmrs.module.scheduler.web.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openmrs.api.context.Context;
import org.openmrs.api.db.UserDAO;
import org.openmrs.util.PrivilegeConstants;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping; import org.springframework.web.bind.annotation.RequestMethod;
import org.openmrs.User;
import org.openmrs.Role;

import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

/**
 * The main controller.
 */
@Controller
public class OpenMRSSchedulerManageController {
	
	protected final Log log = LogFactory.getLog(getClass());

	private List<User> getDoctors() {
		Context.addProxyPrivilege("Get Users");
		List<User> users = Context.getUserService().getUsersByRole(new Role("Clinician"));
		return users;
	}
	
	@RequestMapping(value = "/module/scheduler/manage", method = RequestMethod.GET)
	public void manage(ModelMap model) {
		User remoteUser = Context.getAuthenticatedUser();
		boolean loggedIn = remoteUser != null;

		model.addAttribute("loggedIn", loggedIn);
		model.addAttribute("user", remoteUser);
		model.addAttribute("doctors", getDoctors());
	}

	@RequestMapping(value = "/module/scheduler/post_appointment", method = RequestMethod.PUT)
	public ResponseEntity postAppointment(@RequestBody ModelMap model) {
		System.out.println(model);
		return new ResponseEntity(HttpStatus.OK);
	}

	@RequestMapping(value = "/module/scheduler/post_preferences", method = RequestMethod.PUT)
	public ResponseEntity postPreferences(@RequestBody ModelMap model) {
		System.out.println(model);
		return new ResponseEntity(HttpStatus.OK);
	}
}
