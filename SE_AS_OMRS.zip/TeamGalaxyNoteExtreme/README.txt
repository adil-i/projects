Team: GalaxyNoteExtreme
Members: Adil Iqbal, Kan Xue, Jules Skril, David More

Files included:

Openmrs folder(and subfolders):
pom.xml(OpenMRS dependencies)
Config.xml
WebModuleApplicationContext.xml
OpenMRSSchedulerManageController.java
AdminList.java
Manage.jsp
Javascriptinclude.jsp
localHeader.jsp
stylesheetInclude.jsp

DBcode:
OpenMRSSchedulerManageController.java (backend DB code but weren't able to have it communicates with front end)


Documentation folder:
Project details.txt
Quickstart Guide.txt
Limitations.txt
Schema.txt
Working detail.txt
Installation.txt

Sprint folder:
Sprint and burndown charts

Testing folder:
Sample and result.doc
Testing instructions.doc
