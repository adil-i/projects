# coding: utf-8

# In[32]:

import math


# In[19]:

def PreWordCount(inputFile, wordCount, Model):
	with open(inputFile, "r") as file:
		for line in file:
			line = line.lower()
			if Model == "unigram":
				for word in line.split():
					if word not in wordCount:
						wordCount[word] = 1
					else:
						wordCount[word] += 1
			else: 
				lineAsList = line.split()
				for i in range(len(lineAsList) - 1):
					wordTuple = (lineAsList[i], lineAsList[i+1])
					if wordTuple not in wordCount:
						wordCount[wordTuple] = 1
					else:
						wordCount[wordTuple] += 1


# In[20]:

def writeToFile(inputFile, wordCount):
	outputFile = open("new-" + inputFile, "w")
	wordCount["<unk>"] = 0
	wordCount["<s>"] = 0
	wordCount["</s>"] = 0
	with open(inputFile, "r") as inFile:
		for line in inFile:
			line = line.lower()
			wordCount["<s>"] += 1
			outputFile.write("<s>")
			for word in line.split():
				if wordCount[word] == 1:
					outputFile.write(" <unk>")
					wordCount["<unk>"] += 1
					del wordCount[word]
				else:
					outputFile.write(" " + word)
			wordCount["</s>"] += 1
			outputFile.write(" </s>\n")
	outputFile.close()


# In[21]:

def modifyTestFile(testFile, wordCount) :
	outputFile = open("new-" + testFile, "w")
	with open(testFile, "r") as inFile:
		for line in inFile:
			line = line.lower()
			outputFile.write("<s>")
			for word in line.split():
				if word not in wordCount:
					outputFile.write(" <unk>")
				else:
					outputFile.write(" " + word)
			outputFile.write(" </s>\n")
	outputFile.close()


# In[30]:

def totalCountOf(wordCount):
	totalCount = 0.0
	for count in wordCount.values():
		totalCount += count
	return totalCount

def percentMissingUnigram(testFile, wordCount):
	countMissing = 0.0
	countTotal = 0.0
	with open(testFile, "r") as inFile:
		for line in inFile:
			line = line.lower()
			for word in line.split():
				countTotal += 1
				if word not in wordCount:
					countMissing += 1
	return countMissing / countTotal

def percentMissingBigram(testFile, wordCount):
	countMissing = 0.0
	countTotal = 0.0
	with open(testFile, "r") as inFile:
		for line in inFile:
			lineAsList = line.split()
			for i in range(len(lineAsList) - 1):
				countTotal += 1
				wordTuple = (lineAsList[i], lineAsList[i+1])
				if wordTuple not in wordCount:
					countMissing += 1
	return countMissing/countTotal
def unigramProbability(sentence, wordCount, size):
	prob = 1.0
	for word in sentence.split()[1:]: 
		prob *= (wordCount[word] / size)
	return prob

def bigramProbability(sentence, uniWordCount, biWordCount):
	lineAsList = sentence.split()
	prob = 1.0
	for i in range(len(lineAsList) - 1):
		wordTuple = (lineAsList[i], lineAsList[i+1])
		if wordTuple not in biWordCount:
			return 0
		prob *= (biWordCount[wordTuple] / float(uniWordCount[lineAsList[i]]))
	return prob

def bigramAddOne(sentence, uniWordCount, biWordCount):
	lineAsList = sentence.split()
	prob = 1.0
	v = Size(uniWordCount)
	for i in range(len(lineAsList) - 1):
		wordTuple = (lineAsList[i], lineAsList[i+1])
		if wordTuple not in biWordCount:
			prob *= (1.0 / (float(uniWordCount[lineAsList[i]]) + v))
		else: 
			prob *= (biWordCount[wordTuple] + 1.0) / (float(uniWordCount[lineAsList[i]]) + v)
	return prob

def logUnigramProbability(sentences, wordCount, size):
	prob = 0.0
	for line in sentences.split("\n"):
		sentenceProb = unigramProbability(line, wordCount, size)
		if sentenceProb == 0: 
			return "undefined"
		else:
			prob += math.log(sentenceProb, 2)
	return prob
	

def logBigramProbability(sentences, uniWordCount, biWordCount):
	prob = 0.0
	for line in sentences.split("\n"):
		sentenceProb = bigramProbability(line, uniWordCount, biWordCount)
		if sentenceProb == 0: 
			return "undefined"
		else: prob += math.log(sentenceProb, 2)
	return prob

def logBigramAddOne(sentences, uniWordCount, biWordCount):
	prob = 0.0
	for line in sentences.split("\n"):
		sentenceProb = bigramAddOne(line, uniWordCount, biWordCount)
		if sentenceProb == 0: 
			return "undefined"
		else: prob += math.log(sentenceProb, 2)
	return prob

def perplexity(model, sentences, uniWordCount, biWordCount, numWords):
	M = 0
	for words in sentences.split():
		M += 1

	if model == "unigram":
		if logUnigramProbability(sentences, uniWordCount, numWords) == "undefined":
			return 1000
		else:
			l = (1.0/M) * logUnigramProbability(sentences, uniWordCount, numWords)
	elif model == "bigram":
		if logBigramProbability(sentences, uniWordCount, biWordCount) == "undefined":
			return 1000
		else:
			l = (1.0/M) * logBigramProbability(sentences, uniWordCount, biWordCount)
	else:
		if logBigramAddOne(sentences, uniWordCount, biWordCount) == "undefined":
			return 1000
		else:
			l = (1.0/M) * logBigramAddOne(sentences, uniWordCount, biWordCount)
	return (2 ** (l * -1))

def Size(uniWordCount):
	count = 0
	for word in uniWordCount:
		count += 1
	return count

def printOutWordCount(wordCount):
	for word, count in wordCount.items():
		print(word, count)


# In[23]:

uniWordCount = {}
PreWordCount("brown-train.txt", uniWordCount, "unigram")
writeToFile("brown-train.txt",  uniWordCount)
modifyTestFile("brown-test.txt", uniWordCount)
modifyTestFile("learner-test.txt", uniWordCount)
uniWordCountSize = totalCountOf(uniWordCount)
biWordCount = {}
PreWordCount("new-brown-train.txt", biWordCount, "bigram")


# In[29]:

print("Unique Word Count", len(uniWordCount))
print("Number of tokens" , uniWordCountSize)
print("% of missing words in brown-test.txt",
percentMissingUnigram("brown-test.txt", uniWordCount))
print("% of missing words in learner-test.txt", 
percentMissingUnigram("learner-test.txt", uniWordCount))
print("% of missing bigram types in brown-test.txt",
percentMissingBigram("brown-test.txt", biWordCount))
print("% of missing bigram types in learner-test.txt", 
percentMissingBigram("learner-test.txt", biWordCount))


# In[35]:

data = "<s> he was laughed off the screen . </s>"
print("The following uses this data:" + "\"" + data + "\"")
print("Unigram:", logUnigramProbability(data, uniWordCount, uniWordCountSize))
print("Bigram:", logBigramProbability(data, uniWordCount, biWordCount))
print("Bigram Add One:", logBigramAddOne(data, uniWordCount, biWordCount))
print("Unigram Perplexity:", perplexity("unigram", data, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram Perplexity:", perplexity("bigram", data, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram Add One Perplexity:", perplexity("bigram add one", data, uniWordCount, biWordCount, uniWordCountSize))

data = "<s> there was no <unk> behind them . </s>"
print("The following uses this data:" + "\"" + data + "\"")
print("Unigram:", logUnigramProbability(data, uniWordCount, uniWordCountSize))
print("Bigram:", logBigramProbability(data, uniWordCount, biWordCount))
print("Bigram Add One:", logBigramAddOne(data, uniWordCount, biWordCount))
print("Unigram Perplexity:", perplexity("unigram", data, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram Perplexity:", perplexity("bigram", data, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram Add One Perplexity:", perplexity("bigram add one", data, uniWordCount, biWordCount, uniWordCountSize))

data = "<s> i look forward to hearing your reply . </s>"
print("The following uses this data:" + "\"" + data + "\"")
print("Unigram:", logUnigramProbability(data, uniWordCount, uniWordCountSize))
print("Bigram:", logBigramProbability(data, uniWordCount, biWordCount))
print("Bigram Add One:", logBigramAddOne(data, uniWordCount, biWordCount))
print("Unigram Perplexity:", perplexity("unigram", data, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram Perplexity:", perplexity("bigram", data, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram Add One Perplexity:", perplexity("bigram add one", data, uniWordCount, biWordCount, uniWordCountSize))

corpus = ""
with open("new-brown-test.txt", "r") as file:
    for line in file:
        corpus += line
print("Unigram - brown test: ",perplexity("unigram", corpus, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram - brown test: ", perplexity("bigram", corpus, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram Add One - brown test: ", perplexity("bigram add one", corpus, uniWordCount, biWordCount, uniWordCountSize))

corpus = ""
with open("new-learner-test.txt", "r") as file:
    for line in file:
        corpus += line
print("Unigram - learner test: ", perplexity("unigram", corpus, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram - learner test: ", perplexity("bigram", corpus, uniWordCount, biWordCount, uniWordCountSize))
print("Bigram Add One - learner test: ", perplexity("bigram add one", corpus, uniWordCount, biWordCount, uniWordCountSize))

