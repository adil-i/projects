import java.io.*;
import java.util.*;
class Sentence {
	ArrayList<String> words;
	public Sentence(String origText) {
		words = new ArrayList<>();
		StringTokenizer st = new StringTokenizer(origText);
		while(st.hasMoreTokens())words.add(st.nextToken());
	}
	public Sentence(){}
	int length() {
		return words.size();
	}
	String wordAt(int a){
		return words.get(a);
	}
	public String toString(){
		String l = "";
		for(int i=0;i<words.size();i++)
			{
				l+= words.get(i);
				l+=" ";
			}
		return l;
	}
}

class Dependency {
	String word1, word2;
	public String toString(){
		return word1 +"-->"+word2;
	}
}
public class Comp {
	
	
	static Sentence readSentence(BufferedReader r) throws IOException{
		String line1 ="";
		String line ="";
		while(true) {
			line1= r.readLine();
			if(line1 == null || line1.equals("")) break;
			line += line1;
		}
			StringTokenizer st = new StringTokenizer(line,")");
			String word;
			Sentence ret = new Sentence();
			ret.words = new ArrayList<>();
			while(st.hasMoreTokens()){
				word = st.nextToken();
				StringTokenizer st2 = new StringTokenizer(word);
				while(st2.hasMoreTokens()) word = st2.nextToken();
				ret.words.add(word);
			}
		
		return ret;
	}
	
	static ArrayList<Set<String>> getErrorWords (Sentence correct, Sentence incorrect, Map<String, String> correctToIncorrect) {
		ArrayList<Set<String>> l = new ArrayList<Set<String>>();
		Set<String> missing = new HashSet<String>();
		Set<String> unnecesary = new HashSet<String>();
		int[][][] dp = new int[correct.length()+1][incorrect.length()+1][2];
		//0->unnecessary
		//1->missing
		//2->match
		for(int i=0;i<=incorrect.length();i++) 
			dp[0][i][0] = i;
		for(int i=0;i<=correct.length();i++)
		{	dp[i][0][0] =i;
			dp[i][0][1] =1;
		}
		dp[0][0][1] =2;
		
		for(int i=1;i<=correct.length();i++)
			for(int j=1;j<=incorrect.length();j++)
			{
				if(correct.wordAt(i-1).equals(incorrect.wordAt(j-1))){
					dp[i][j][0]= dp[i-1][j-1][0];
					dp[i][j][1] = 2;
					
					if( dp[i][j-1][0] + 1 < dp[i][j][0]) {
						dp[i][j][0] =  dp[i][j-1][0] + 1;
						dp[i][j][1] = 0;
					}
					if(dp[i-1][j][0] + 1 < dp[i][j][0]){
						dp[i][j][0] =  dp[i-1][j][0] + 1;
						dp[i][j][1] = 1;
					}
				}
				else {
					dp[i][j][0]= dp[i-1][j-1][0] + 2;
					dp[i][j][1] = 2;
					
					if( dp[i][j-1][0] + 1 < dp[i][j][0]) {
						dp[i][j][0] =  dp[i][j-1][0] + 1;
						dp[i][j][1] = 0;
					}
					if(dp[i-1][j][0] + 1 < dp[i][j][0]){
						dp[i][j][0] =  dp[i-1][j][0] + 1;
						dp[i][j][1] = 1;
					}
				}
			}
		int i=correct.length(), j=incorrect.length();
		while(i>0 && j>0) {
			if(correct.wordAt(i-1).equals(incorrect.wordAt(j-1))) {
				switch(dp[i][j][1]) {
				case 2:
					i--;
					j--;
					correctToIncorrect.put(correct.wordAt(i)+"-"+(i+1), incorrect.wordAt(j)+"-"+(j+1));
					break;
				case 1:
					missing.add(correct.wordAt(i-1).concat("-"+(i)));
					i--;
					break;
				case 0:
					unnecesary.add(incorrect.wordAt(j-1).concat("-"+(j)));
					j--;
					break;
				}
			}
			else {
				switch(dp[i][j][1]) {
				case 2:
					missing.add(correct.wordAt(i-1).concat("-"+(i)));
					unnecesary.add(incorrect.wordAt(j-1).concat("-"+(j)));
					i--;
					j--;
					break;
				case 1:
					missing.add(correct.wordAt(i-1).concat("-"+(i)));
					i--;
					break;
				case 0:
					unnecesary.add(incorrect.wordAt(j-1).concat("-"+(j)));
					j--;
					break;
				}
			}
		}
		l.add(missing);
		l.add(unnecesary);
		return l;
	}
	
	static ArrayList<Dependency> readDependency(BufferedReader r) throws IOException {
		String line ="";
		ArrayList<Dependency> set = new ArrayList<Dependency>();
			while(true) {
				line=r.readLine();
				if(line==null || line.equals("")) break;
				StringTokenizer st = new StringTokenizer(line, "(,)");
				st.nextToken();
				Dependency d = new Dependency();
				String word1 = st.nextToken().trim();
				String word2 = st.nextToken().trim();
				d.word1=word1;
				d.word2=word2;
				set.add(d);
			}			
		return set;
	}

	public static void main(String[] args) throws IOException {
		
		BufferedReader rinc = new BufferedReader(new FileReader(new File("original-parsetree.txt")));
		BufferedReader rcor = new BufferedReader(new FileReader(new File("corrected-parsetree.txt")));
		for(int i=0;i<10;i++ ){
			int extrD=0, misD=0, noDepG=0, noDepUng=0;
			int shared=0;
			Sentence orig = readSentence(rinc);
			Sentence corr = readSentence(rcor);
			Map<String, String> c2i = new HashMap<String, String>();
			ArrayList<Set<String>> l = getErrorWords(orig, corr, c2i);
			
			ArrayList<Dependency> cd = readDependency(rcor);
			ArrayList<Dependency> id = readDependency(rinc);
			Set<String> missing = l.get(0);
			Set<String> extra = l.get(1);
			
			for(Dependency d: cd) {
				if (missing.contains(d.word1) || missing.contains(d.word2)) misD++;
			}
			for(Dependency d: id) {
				if (extra.contains(d.word1) || extra.contains(d.word2)) extrD++;
			}
			
			
			c2i.put("ROOT-0", "ROOT-0");
			for(Dependency d:cd){
				for(Dependency d2:id){
					if(d2.word1.equals(c2i.get(d.word1)) && d2.word2.equals(c2i.get(d.word2))) {
						shared++;
					}
				}
			}
			noDepG += cd.size();
			noDepUng += id.size();
			double pre = calculatePrecision(shared, misD, extrD, noDepG, noDepUng);
			double recall =calculateRecall(shared, misD, extrD, noDepG, noDepUng);
			double f = calculateF(pre, recall);
			
			System.out.println("Precision: "+ pre) ;
			System.out.println("Recall:"+ recall);
			System.out.println("F:"+f);
			
		}
		
		
	}

	private static double calculateF(double pr, double rec) {
		return (2*pr*rec)/(pr+rec);
	}

	private static double calculatePrecision(int shared, int misD, int extrD, int noDepG, int noDepUng) {
		double ret = ((double)shared)/ (noDepUng-extrD);
		return ret;
	}

	private static double calculateRecall(int shared, int misD, int extrD, int noDepG, int noDepUng) {
		double ret = ((double)shared)/ (noDepG-misD);
		return ret;
	}
}