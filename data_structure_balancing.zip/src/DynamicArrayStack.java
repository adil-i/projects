public class DynamicArrayStack<AnyType> implements Stack<AnyType>
{
	public static final int DEFAULT_CAPACITY = 1024;
	AnyType[] data;
	int topOfStack;
	int maxSize;

	public DynamicArrayStack() { this(DEFAULT_CAPACITY); }

	public DynamicArrayStack(int capacity)
	{
		topOfStack = -1;
		data = (AnyType[]) new Object[capacity];
		maxSize = capacity;
	}

	public int size()
	{
		return topOfStack + 1;
	}

	public boolean isEmpty()
	{
		if(size() <= 0) {
			return true;
		} else {
			return false;
		}
	}

	public void push(AnyType newValue)
	{
		// Resize if the stack is full
		if(size() >= maxSize)
			resize(2 * maxSize);
		if(size() == 0)
			resize(1);
		// Push to top of stack
		data[++topOfStack] = newValue;
	}
	
	protected void resize(int newCapacity)
	{
		int n = size();

		AnyType[] temp = (AnyType[]) new Object[newCapacity];
		for (int i=0; i < n; i++)
			temp[i] = data[i];
		data = temp;
		maxSize = newCapacity;
	}

	public AnyType top()
	{
		// Return top value only if the stack is non empty
		if(isEmpty())
			return null;
		else
			return data[topOfStack];
	}

	public AnyType pop()
	{
		// Return and remove the top value only if the stack is non empty
		if(isEmpty())
			return null;
		else {
			AnyType temp = top();
			topOfStack--;
			// Resize only when less than quarter full
			if (size() < maxSize/4) {
				resize(maxSize/2);
			}
			return temp;
		}
	}
}
