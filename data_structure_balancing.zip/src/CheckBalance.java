import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class CheckBalance {
	
	private FileInputStream fstream;
	
	public CheckBalance() {
		// Do not instantiate if no filename is supplied
		throw new IllegalArgumentException("Empty File Name");
	}
	
	public CheckBalance(String fileName) throws FileNotFoundException {
		fstream = new FileInputStream(fileName);
	}
	
	private char readChar() throws IOException {
		if(fstream.available() > 0)
			return (char) fstream.read();
		else
			return 0;
	}
	
	private boolean canRead() throws IOException {
		if(fstream.available() > 0)
			return true;
		else
			return false;
	}
	
	public void processFile() throws IOException {
		DynamicArrayStack<Character> brackets = new DynamicArrayStack<Character>();
		if(!canRead()) {
			System.out.println("Empty File!");
			return;
		}
		while(canRead()) {
			char c = readChar();
			System.out.print(c);
			switch(c) {
			case '(':
			case '{':
			case '[':
				brackets.push(c);
				break;
				
			case ')':
				// Check if our stack is empty, if so then the expression cannot be balanced
				// Then we check if the matching closed parenthesis is present, if so we continue out checking
				if(brackets.isEmpty() || brackets.top() != '(') {
					System.out.println("\nThe given expression is not well balanced");
					return;
				} else {
					brackets.pop();
				}
				break;
				
			case '}':
				if(brackets.isEmpty() || brackets.top() != '{') {
					System.out.println("\nThe given expression is not well balanced");
					return;
				} else {
					brackets.pop();
				}
				break;
				
			case ']':
				if(brackets.isEmpty() || brackets.top() != '[') {
					System.out.println("\nThe given expression is not well balanced");
					return;
				} else {
					brackets.pop();
				}
				break;
			}
		}
		if(brackets.isEmpty())
			System.out.println("\nThe given expression is balanced");
		else
			System.out.println("\nThe given expression is not well balanced");
	}
}