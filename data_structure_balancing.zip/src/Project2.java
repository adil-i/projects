import java.io.FileNotFoundException;
import java.io.IOException;

public class Project2 {

	public static void main(String[] args) {
		try {
			CheckBalance test = new CheckBalance("project2.txt");
			test.processFile();
		} catch (FileNotFoundException e) {
			System.out.println("File not found! :s");
		} catch (IOException e) {
			System.out.println("File I/O operation exception");
		}
	}
}
