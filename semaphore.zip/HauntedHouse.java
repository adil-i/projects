import java.util.*;
import java.util.concurrent.Semaphore;

public class HauntedHouse 
{

	public static int Npassenger = 11;
	public static int Ncar = 3;
	public static int capacity = 4;
	
	private Semaphore tryCarSem;
	private Semaphore moreRidesSem;
	Semaphore[] sem;
	Vector<Passenger> queue;
	Passenger [] pass;
	Car [] cars;
	Vector<Car> availableCars;
	Vector<Car> goneCars;
	int totalRides = 0;
	
	public static long time = System.currentTimeMillis();

	public static void main(String[] args) throws InterruptedException
	{
//		//get the names of the passengers before starting the ride
//		System.out.println("Give the names of all the passengers:");
		if(args.length>0)
			Npassenger = Integer.parseInt(args[0]);
		if(args.length>1)
			Ncar = Integer.parseInt(args[1]);
		if(args.length>2)
			capacity = Integer.parseInt(args[2]);
		
		
		
		HauntedHouse house = new HauntedHouse();
		house.startTour();
		
		//every waiting operation has to be performed using the join() operation and not the wait() operation 
	}

	private void startTour() throws InterruptedException {
		// TODO Auto-generated method stub
		queue = new Vector<Passenger>();
		pass = new Passenger[Npassenger];
		cars = new Car[Ncar];
		goneCars = new Vector<Car>();
		availableCars = new Vector<Car>();
		tryCarSem = new Semaphore(1);
		moreRidesSem = new Semaphore(1);

		for(int i=0;i<Ncar;i++) {
			cars[i] = new Car(i,queue, capacity,availableCars,this);
			availableCars.add(cars[i]);
		}
		sem = new Semaphore[Npassenger];
		for(int i=0;i<Npassenger;i++) sem[i] = new Semaphore(0);
		for(int i=0;i<Npassenger;i++) pass[i] = new Passenger(i, queue, pass, availableCars, this, sem);
		
		for(int i=0;i<Npassenger;i++) pass[i].start();
		for(int i=0;i<Ncar;i++) cars[i].start();
		for(int i=0;i<Ncar;i++) cars[i].join();
	}
	public boolean tryCar(Passenger p) throws InterruptedException {
		tryCarSem.acquire();
		if(availableCars.size()!=0) {
			for(int i=0;i<availableCars.size();i++){
				if(availableCars.get(i).addPassenger(p)) {
					queue.remove(p);
					totalRides++;
					if(!moreRides()) {
						for(int j=0;j<availableCars.size();j++){
							availableCars.get(i).canGo.release();
						}
					}
					tryCarSem.release();
					return true;
				}
			}	
		}
		tryCarSem.release();
		return false;
	}

	public boolean moreRides() throws InterruptedException{
		moreRidesSem.acquire();
		if(totalRides<Npassenger*3) {
			moreRidesSem.release();
			return true;
		}
		moreRidesSem.release();
		return false;
	}
	
}
