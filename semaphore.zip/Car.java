import java.util.Vector;
import java.util.concurrent.Semaphore;

public class Car extends Thread
{
	public int CarNum;
	public Vector<Passenger> seats;
	private int capacity;
	private Semaphore seatsSem;
	Vector<Passenger> queue;
	Vector<Car> availableCars;
	HauntedHouse hauntedHouse;
	Semaphore canGo;
	
	public static long time = System.currentTimeMillis();
	
	public Car(int carId, Vector<Passenger> queue, int capacity, Vector<Car> availableCars, HauntedHouse hauntedHouse)
	{
		this.queue = queue;
		this.seats = new Vector<Passenger>();
		this.capacity=capacity;
		this.hauntedHouse=hauntedHouse;
		this.availableCars = availableCars;
		this.seatsSem = new Semaphore(1);
		canGo = new Semaphore(0);
		setName("Car - "+carId);
	}
	

	public void msg(String m) {
	System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+":"+m);
	}
	
	public void run () 
	{
		try {
			while(hauntedHouse.moreRides())
			{
				 // wait till the capacity is reached.
				//make an exception for the very last ride
				msg("is waiting for passengers");
				canGo.acquire();

				availableCars.remove(this);
				//print on the terminal before going for a ride
				msg("going to the haunted house");
				//sleep for a fixed time for the journey.
				try {
					sleep(8000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				msg("has come back from the haunted house");
				
				//send notification to all passenger threads
				msg("interrupting all passengers to wake them up");
					for(int i=0;i<seats.size();i++){
						seats.get(i).interrupt();
					}

				
				
				//wait for passengers to get out
				msg("waiting for passengers to leave the car");
				while(seats.size()!=0);
				availableCars.add(this);
				msg("car is available for next ride");
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		msg("is exiting");
	   
	}
	public boolean addPassenger(Passenger p) {
		try {
			seatsSem.acquire();
			if(seats.size()<capacity) {
				seats.add(p);
				p.currentCar = this;
				msg(p.getName()+" got in " +this.getName());
				if(seats.size()==capacity) 
					canGo.release();

				seatsSem.release();
				return true;
			}
			seatsSem.release();
			return false;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public void getOut(Passenger p) {
		try {
			seatsSem.acquire();
			seats.remove(p);
			p.currentCar=null;
			msg(""+p.getName()+" got out of "+this.getName());
			seatsSem.release();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
