public class Polynomial {

    private DoublyLinkedList<Term> termList;
    
    public Polynomial(){
        termList = new DoublyLinkedList<>();
    }
    
    public int getSize(){
        return termList.size();
    }
    
    public Term getTerm(int i){
        return termList.get(i);
    }
    
    //To add 2 polynomials we take first elements of both until and compare
    //If their exponents are equal we add the two elements and add that term to result
    //if not then we take the larger term and add it to the list and increment the index of
    //the polynomial from which the term was taken
    public static Polynomial add(Polynomial a, Polynomial b){
        Polynomial result = new Polynomial();
        int i=0, j=0;
        //we compare term by term and add the biggest first
        //if exponents are same
        while(i<a.getSize() && j<b.getSize()){
            if(a.getTerm(i).getExponent()>b.getTerm(j).getExponent()){
                result.addTerm(a.getTerm(i));
                i++;
            } else if(b.getTerm(j).getExponent()>a.getTerm(i).getExponent()){
                result.addTerm(b.getTerm(j));
                j++;
            } else {
                double addedCoefficent = a.getTerm(i).getCoefficient() + b.getTerm(j).getCoefficient();
                int exponent = a.getTerm(i).getExponent();  //as a and b have same exponent, we can take any
                Term addedTerm = new Term(addedCoefficent, exponent);
                result.addTerm(addedTerm);
                i++;
                j++;
            }
        }
        while(i<a.getSize()){
            result.addTerm(a.getTerm(i));
            i++;
        }
        while(j<b.getSize()){
            result.addTerm(b.getTerm(j));
            j++;
        }
        return result; 
    }
    
    //we know that a - b can be written as a + (-b) so to subtract we first find
    //negative of polynomial b and then add it to a to get a - b
    public static Polynomial subtract(Polynomial a, Polynomial b){
        Polynomial minusB = b.getNegative();
        Polynomial result = Polynomial.add(a, minusB);
        
        return result;
    }
    
    //to multiply two polynomials we simply generate all the elements that will be generated 
    //by every term in a to every term in b
    //then we add these terms to the result
    //the function addTerm() is intelligent enough to add two terms if their exponents are same
    public static Polynomial multiply(Polynomial a, Polynomial b){
        Polynomial result = new Polynomial();
        int i=0, j=0;
        for(i=0; i<a.getSize(); i++){
            for(j=0; j<b.getSize(); j++){
                double tempCoefficient = a.getTerm(i).getCoefficient()*b.getTerm(j).getCoefficient();
                int tempExponent = a.getTerm(i).getExponent()+b.getTerm(j).getExponent();
                Term temp = new Term(tempCoefficient,tempExponent);
                result.addTerm(temp);
            }
        }
        return result;
    }
    
    public void addTerm(double termCoefficient, int termExponent){
        if (termCoefficient == 0){
            return;
        }
        Term termToAdd = new Term(termCoefficient,termExponent);
        if(termList.isEmpty()){
            termList.add(termToAdd);
            return;
        }
        //we have to add this new term at the correct position on the list
        //so we travese untill we find a position at which the newTerm is greater
        //than all the terms next to it
        //if it's exponent are equal to some term, we simply add the coefficients
        int i = 0;
        while(i<termList.size() && termToAdd.getExponent()<termList.get(i).getExponent()){
            i++;                                        
        }
        //now once we have found a position where we can add
        //we check if the term already present there has the same exponent
        //if yes we just change the coeffficent
        //if no we add the term at this index
        if(i<termList.size() && termToAdd.getExponent() == termList.get(i).getExponent()){
            termToAdd.setCoefficient(termToAdd.getCoefficient()+termList.get(i).getCoefficient());
            termList.set(i, termToAdd);
        } else {
            termList.add(i,termToAdd);
        }
        
    }

    public void addTerm(Term term) {
        this.addTerm(term.getCoefficient(),term.getExponent());
    }

    public Polynomial getNegative() {
        for(int i=0; i<termList.size();i++){
            Term temp = termList.get(i);
            temp.setCoefficient(-1*temp.getCoefficient());
            termList.set(i, temp);
        }
        return this;
    }
    
    //to print a polynomial
    @Override
    public String toString(){
        String polynomialString = "";
        polynomialString += processTerm(termList.get(0)).substring(3);  //for first string we don't need + or - sign
        for(int i=1;i<termList.size();i++){
            Term tempTerm = termList.get(i);
            polynomialString += processTerm(tempTerm);
        }
        return polynomialString;
    }
    //if coefficient is 1 we dont print 1
    //if next coefficient is positive we print +
    //if it is negative we print -
    //if exponent is zero we don't print x^0
    private String processTerm(Term term){
        String termString = "";
        
        boolean positive = term.getCoefficient()>0;
        boolean coefIsOne = Math.abs(term.getCoefficient()) == 1;
        boolean expIsZero = term.getExponent()==0;
        
        if(positive && coefIsOne && expIsZero){
            termString += " + 1"; 
        }
        if(positive && coefIsOne && !expIsZero){
            termString += " + x^" + term.getExponent(); 
        }
        if(positive && !coefIsOne && expIsZero){
            termString += " + "+ term.getCoefficient(); 
        }
        if(positive && !coefIsOne && !expIsZero){
            termString += " + "+term.getCoefficient()+"x^"+term.getExponent(); 
        }
        if(!positive && coefIsOne && expIsZero){
            termString += " - 1"; 
        }
        if(!positive && coefIsOne && !expIsZero){
            termString += " - x^" + term.getExponent(); 
        }
        if(!positive && !coefIsOne && expIsZero){
            termString += " - "+(-term.getCoefficient()); 
        }
        if(!positive && !coefIsOne && !expIsZero){
            termString += " - "+(-term.getCoefficient())+"x^"+term.getExponent(); 
        }
        return termString;
    }
    
}
