public class Term implements Comparable<Term>{
    private double coefficient;
    private int exponent;
    
    public Term(double coef, int exp){
        coefficient = coef;
        exponent = exp;
    }

    /**
     * @return the coefficient
     */
    public double getCoefficient() {
        return coefficient;
    }

    /**
     * @param coefficient the coefficient to set
     */
    public void setCoefficient(double coefficient) {
        this.coefficient = coefficient;
    }

    /**
     * @return the exponent
     */
    public int getExponent() {
        return exponent;
    }

    /**
     * @param exponent the exponent to set
     */
    public void setExponent(int exponent) {
        this.exponent = exponent;
    }

    @Override
    public int compareTo(Term other) {
        if(this.exponent == other.getExponent()){
            if(this.coefficient == other.getCoefficient()){
                return 0;
            } else if(this.coefficient < other.getCoefficient()){
                return -1;
            } else if(this.coefficient > other.getCoefficient()){
                return 1;
            }
        } else {
            if(this.exponent < other.exponent){
                return -1;
            } else if(this.exponent > other.getExponent()){
                return 1;
            }
        }
        return 0;
    }
}
