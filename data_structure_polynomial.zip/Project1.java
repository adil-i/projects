import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Project1 {
    public static void main(String args[]){
        File inputFile = null;
        FileReader fr = null;
        BufferedReader br = null;
        String polynomial1, polynomial2, operation;
        try {    
            inputFile = new File("project1.txt");
            fr = new FileReader(inputFile);
            br = new BufferedReader(fr);
            while((polynomial1=br.readLine())!=null && (polynomial2=br.readLine())!=null && (operation=br.readLine())!=null){
            OperationProcessor.processOperation(polynomial1.trim(), polynomial2.trim(), operation.trim());
            }
            br.close();
            fr.close();
                
        } catch (FileNotFoundException ex) {
            System.out.println("File project1.txt does not exist");
        } catch (IOException ex) {
            System.out.println("Cannot read file!");
        } 

    }
}
