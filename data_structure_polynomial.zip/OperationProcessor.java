public class OperationProcessor {
    public static void processOperation(String poly1, String poly2, String operation){
        
        Polynomial p1 = createPolynomialFromString(poly1);
        if(p1==null){
            System.out.println("Moving to next operation");
            return;
        }
        Polynomial p2 = createPolynomialFromString(poly2);
        if(p2==null){
            System.out.println("Moving to next operation");
            return;
        }
        
        if(operation.equals("add")){
            Polynomial result = Polynomial.add(p1, p2);
            System.out.println(p1);
            System.out.println("+  "+p2.toString());
            System.out.println("=");
            System.out.println(result);
            System.out.println();
        } else if(operation.equals("subtract")){
            Polynomial result = Polynomial.subtract(p1, p2);
            System.out.println(p1);
            System.out.println("-  ("+p2.toString()+")");
            System.out.println("=");
            System.out.println(result);
            System.out.println();            
        } else if (operation.endsWith("multiply")){
            Polynomial result = Polynomial.multiply(p1, p2);
            System.out.println(p1);
            System.out.println("*  "+p2.toString());
            System.out.println("=");
            System.out.println(result);
            System.out.println();            
        } else {
            System.out.println("Invalid Operation: "+operation);
        }
    }
    
    private static Polynomial createPolynomialFromString(String polynomialString){
        Polynomial poly = new Polynomial();
        String[] tokens = polynomialString.split(" ");
        try {
            for(int i=0; i<tokens.length; i+=2){
                double coef = Double.parseDouble(tokens[i]);
                int exp = Integer.parseInt(tokens[i+1]);
                Term newTerm = new Term(coef,exp);
                poly.addTerm(newTerm);
            }
        } catch(NumberFormatException e){
            System.out.println("Error Creating Polynomial. Invalid polynomial expression. "+polynomialString);
            return null;
        }
        return poly;
    }
}