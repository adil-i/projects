import java.util.Vector;

public class Car extends Thread
{
	public int CarNum;
	public Vector<Passenger> seats;
	private int capacity;
	
	Vector<Passenger> queue;
	Vector<Car> availableCars;
	HauntedHouse hauntedHouse;
	
	public static long time = System.currentTimeMillis();
	
	public Car(int carId, Vector<Passenger> queue, int capacity, Vector<Car> availableCars, HauntedHouse hauntedHouse)
	{
		this.queue = queue;
		this.seats = new Vector<Passenger>();
		this.capacity=capacity;
		this.hauntedHouse=hauntedHouse;
		this.availableCars = availableCars;
		setName("Car - "+carId);
	}
	

	public void msg(String m) {
	System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+":"+m);
	}
	
	public void run () 
	{
		while(hauntedHouse.moreRides())
		{
			 // wait till the capacity is reached.
			//make an exception for the very last ride
			msg("is waiting for passengers");
			while(seats.size()<capacity && hauntedHouse.moreRides());
			msg("is waiting to be sent");
			//waiting for the car to be sent
			while(!hauntedHouse.sendCar(this));
			//sleep for a fixed time for the journey.
			try {
				sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			hauntedHouse.CarArrived(this);
			
			//send notification to all passenger threads
			msg("interrupting all passengers to wake them up");
				for(int i=0;i<seats.size();i++){
					seats.get(i).interrupt();
				}

			
			
			//wait for passengers to get out
			msg("waiting for passengers to leave the car");
			while(seats.size()!=0);
			availableCars.add(this);
			msg("car is available for next ride");
		}
		msg("is exiting");
	   
	}
	public synchronized boolean addPassenger(Passenger p) {
		if(seats.size()<capacity) {
			seats.add(p);
			p.currentCar = this;
			msg(p.getName()+" got in " +this.getName());
			return true;
		}
		return false;
	}
	
	public synchronized void getOut(Passenger p) {
		seats.remove(p);
		p.currentCar=null;
		msg(""+p.getName()+" got out of "+this.getName());
	}
}
