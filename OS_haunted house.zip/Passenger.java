import java.util.ArrayList;
import java.util.Vector;

public class Passenger extends Thread //implements Runnable
{
	public int PassId;
	public int numRides;
	Vector<Passenger> queue;
	Passenger[] pass;
	Car[] Cars=null;
	private Vector<Car> availableCars;
	private HauntedHouse hauntedHouse;
	Car currentCar;
	
	public static long time = System.currentTimeMillis();

	public Passenger (int threadId, Vector<Passenger> queue, Passenger[] pass, Vector<Car> availableCars, HauntedHouse hauntedHouse)
	{
		setName("Passenger - "+threadId);
		this.hauntedHouse = hauntedHouse;
		PassId = threadId;
		this.queue = queue;
	    this.pass = pass;
	    this.availableCars= availableCars;
		numRides = 0;
	}
	
	public void msg(String m) {
	System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+":"+m);
	}
	
	public Passenger (int threadId, Vector<Passenger> queue, Passenger[] pass, Car[] Cars)
	{
		setName("Passenger - "+threadId);
		PassId = threadId;
		this.queue = queue;
	    this.pass = pass;
	    this.Cars = Cars;
		numRides = 0;
	}
	
	public void run () 
	{
		while(numRides<3)
		{
		
			numRides++;
			queue.add(this);
			
			//the passenger will wait in the queue
			msg("waiting in the queue");
			
			while(queue.get(0)!=this || !hauntedHouse.tryCar(this)) {
				//busy wait for car and turn
			}

			msg("is going to yield before getting in the car");
			//yield before getting into the car
			yield();

			//isInterrupted();
			
		    while(!Thread.interrupted())
		    {//do nothing;
		    	
		    }
		    msg("is going to increase its priority before getting out of the car");
			// set random priority to get off the car
		    Thread.currentThread().setPriority(Thread.NORM_PRIORITY + (int) ((Thread.MAX_PRIORITY-Thread.NORM_PRIORITY) * Math.random()));
			currentCar.getOut(this);
			//sleep for a small time
			msg("sleeping for a short time while getting out of the car");
			try {
				sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//set back the priority 
			Thread.currentThread().setPriority(Thread.NORM_PRIORITY);
			
			//check the numRides
				if(numRides == 3) 
				{
					msg("has completed rides");
					//wonder for sometime and then join the n-1th thread, also check before joining that it is alive.
					try {
						sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					if(PassId!=0)
					{
						if(pass[PassId-1].isAlive())
						{
							try {
								pass[PassId-1].join();
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}	
					msg("has completed rides and thus exiting");
					//if the threadId is 0 then don't join any thread, also check and terminate all the car threads
					
				}
					
				//else repeat the same procedure
		}
	   
	}
}




