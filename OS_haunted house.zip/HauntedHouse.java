import java.util.*;

public class HauntedHouse 
{

	public static int Npassenger = 11;
	public static int Ncar = 3;
	public static int capacity = 4;
	
	Vector<Passenger> queue;
	Passenger [] pass;
	Car [] cars;
	Vector<Car> availableCars;
	Vector<Car> goneCars;
	boolean houseOccupied=false;
	int totalRides = 0;
	
	public static long time = System.currentTimeMillis();

	public static void main(String[] args) throws InterruptedException
	{
//		//get the names of the passengers before starting the ride
//		System.out.println("Give the names of all the passengers:");
		if(args.length>0)
			Npassenger = Integer.parseInt(args[0]);
		if(args.length>1)
			Ncar = Integer.parseInt(args[1]);
		if(args.length>2)
			capacity = Integer.parseInt(args[2]);
		HauntedHouse house = new HauntedHouse();
		house.startTour();
		
		//every waiting operation has to be performed using the join() operation and not the wait() operation 
	}

	private void startTour() throws InterruptedException {
		// TODO Auto-generated method stub
		queue = new Vector<Passenger>();
		pass = new Passenger[Npassenger];
		cars = new Car[Ncar];
		goneCars = new Vector<Car>();
		availableCars = new Vector<Car>();
		
		for(int i=0;i<Ncar;i++) {
			cars[i] = new Car(i,queue, capacity,availableCars,this);
			availableCars.add(cars[i]);
		}
		for(int i=0;i<Npassenger;i++) pass[i] = new Passenger(i, queue, pass, availableCars, this);
		
		for(int i=0;i<Npassenger;i++) pass[i].start();
		for(int i=0;i<Ncar;i++) cars[i].start();
		for(int i=0;i<Ncar;i++) cars[i].join();
	}
	public synchronized boolean tryCar(Passenger p) {
		if(availableCars.size()!=0) {
			for(int i=0;i<availableCars.size();i++){
				if(availableCars.get(i).addPassenger(p)) {
					queue.remove(p);
					totalRides++;
					return true;
				}
			}	
		}
		return false;
	}
	public synchronized boolean sendCar(Car c){
		if(!houseOccupied) {
			houseOccupied=true;
			availableCars.remove(c);
			//print on the terminal before going for a ride
			c.msg("going to the haunted house");
			return true;
		}
		return false;
	}

	public synchronized  void CarArrived(Car car) {
		houseOccupied=false;
		car.msg("has come back from the haunted house");
	}
	public synchronized boolean moreRides(){
		if(totalRides<Npassenger*3) return true;
		return false;
	}
	
}
